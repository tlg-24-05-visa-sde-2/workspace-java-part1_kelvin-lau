package com.entertainment;

public enum DisplayType {
    LED, OLED, PLASMA, LCD, CRT
}